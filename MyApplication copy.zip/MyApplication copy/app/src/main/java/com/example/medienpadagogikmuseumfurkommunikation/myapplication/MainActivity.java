package com.example.medienpadagogikmuseumfurkommunikation.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button calcbutton = (Button)findViewById(R.id.calcbutton);
        calcbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent calc = new Intent(MainActivity.this, CalcActivity.class);
                startActivity(calc);
            }
        });

        Button formulabutton = (Button)findViewById(R.id.formulabutton);
        formulabutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent formula = new Intent(MainActivity.this, FormulaActivity.class);
                startActivity(formula);
            }
        });
    }

}
