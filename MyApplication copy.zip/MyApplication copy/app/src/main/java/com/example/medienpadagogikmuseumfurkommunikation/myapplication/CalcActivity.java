package com.example.medienpadagogikmuseumfurkommunikation.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import static java.lang.Math.sqrt;

import org.w3c.dom.Text;

public class CalcActivity extends AppCompatActivity {

    float Value1, Value2;
    boolean mAddition, mSubtract, mMultiplication, mDivision, mPower, mRoot ;
    int operator;

    /*public String value = new String();
    public void parseString(char character) {
        switch (character) {
            case '1':  monthString = "January";
                break;
            case '2':  monthString = "February";
                break;
            case '3':  monthString = "March";
                break;
            case '4':  monthString = "April";
                break;
            case '5':  monthString = "May";
                break;
            case '6':  monthString = "June";
                break;
            case '7':  monthString = "July";
                break;
            case '8':  monthString = "August";
                break;
            case '9':  monthString = "September";
                break;
            case '0': monthString = "October";
                break;
            case '+': monthString = "November";
                break;
            case '-': monthString = "December";
                break;
            case '/': monthString = "December";
                break;
            case '*': monthString = "December";
                break;
        }
    } */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        Button zero = (Button)findViewById(R.id.button31);
        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("0");
            }
        });

        Button one = (Button)findViewById(R.id.button46);
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("1");
            }
        });

        Button two = (Button)findViewById(R.id.button41);
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("2");
            }
        });

        Button three = (Button)findViewById(R.id.button42);
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("3");
            }
        });

        Button four = (Button)findViewById(R.id.button39);
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("4");
            }
        });

        Button five = (Button)findViewById(R.id.button35);
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("5");
            }
        });

        Button six = (Button)findViewById(R.id.button37);
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("6");
            }
        });

        Button seven = (Button)findViewById(R.id.button40);
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("7");
            }
        });

        Button eight = (Button)findViewById(R.id.button36);
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("8");
            }
        });

        Button nine = (Button)findViewById(R.id.button38);
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append("9");
            }
        });

        Button add = (Button)findViewById(R.id.button45);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                if(t == null) {
                    t.append("");
                } else {
                    Value1 = Float.parseFloat(t.getText() + "");
                    //mAddition = true;
                    operator = 0;
                    t.setText(null);
                }
            }
        });

        Button substract = (Button)findViewById(R.id.button43);
        substract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                Value1 = Float.parseFloat(t.getText() + "");
                mSubtract = true ;
                t.setText(null);
            }
        });

        Button multiply = (Button)findViewById(R.id.button33);
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                Value1 = Float.parseFloat(t.getText() + "");
                mMultiplication = true ;
                t.setText(null);

            }
        });

        Button divide = (Button)findViewById(R.id.button34);
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                Value1 = Float.parseFloat(t.getText()+"");
                mDivision = true ;
                t.setText(null);
            }
        });

        Button clr = (Button)findViewById(R.id.button47);
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.setText("");
            }
        });

        Button equal = (Button)findViewById(R.id.button44);
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                Value2 = Float.parseFloat(t.getText() + "");
                /*switch (operator) {
                    case 0: t.setText(Value1 + Value2 +"");
                        break;
                    case 1: t.setText(Value1 - Value2 +"");
                        break;
                }*/
                if (mAddition == true){

                    t.setText(Value1 + Value2 +"");
                    mAddition=false;
                }


                if (mSubtract == true){
                    t.setText(Value1 - Value2 +"");
                    mSubtract=false;
                }

                if (mMultiplication == true){
                    t.setText(Value1 * Value2 + "");
                    mMultiplication=false;
                }

                if (mDivision == true){
                    t.setText(Value1 / Value2+"");
                    mDivision=false;
                }

                if (mPower == true){
                    t.setText(Value1 * Value1 + "");
                    mPower=false;
                }

                if (mRoot == true){
                    t.setText(sqrt(Value1) + "");

                    mRoot=false;

                }

            }
        });

        Button dec = (Button)findViewById(R.id.button);
        dec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                t.append(".");

            }
        });

        Button power = (Button)findViewById(R.id.button2);
        power.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                Value1 = Float.parseFloat(t.getText()+"");
                mPower = true ;
            }
        });

        Button root = (Button)findViewById(R.id.button32);
        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView t = (TextView)findViewById(R.id.textView3);
                Value1 = Float.parseFloat(t.getText()+"");
                mRoot = true ;
            }
        });



    }
}
