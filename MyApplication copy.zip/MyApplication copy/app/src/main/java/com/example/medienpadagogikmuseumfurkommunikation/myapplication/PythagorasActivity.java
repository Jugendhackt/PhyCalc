package com.example.medienpadagogikmuseumfurkommunikation.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PythagorasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pythagoras);
    }
}
