package com.example.medienpadagogikmuseumfurkommunikation.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FormulaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formula);

        Button pythagorasbutton = (Button)findViewById(R.id.pythagorasbutton);
        pythagorasbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pythagorasbutton = new Intent(FormulaActivity.this, PythagorasActivity.class);
                startActivity(pythagorasbutton);
            }
        });
    }
}
